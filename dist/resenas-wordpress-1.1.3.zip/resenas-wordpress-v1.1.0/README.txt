Reseñas WordPress v1.1.1

Fix: carga robusta de JavaScript y CSS desde el shortcode para garantizar interacción de estrellas.


v1.1.2
- Cierra el ciclo tras pulsar el botón de Google.
- Google se abre en una pestaña nueva y la página de valoración se recarga automáticamente.


v1.1.3
- Cierra también el ciclo de valoraciones 1-3 estrellas.
- Tras guardar el comentario muestra agradecimiento y recarga la página automáticamente.
